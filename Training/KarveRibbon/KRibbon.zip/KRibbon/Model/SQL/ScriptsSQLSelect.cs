﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace KRibbon.Model.SQL
{
    public partial class ScriptsSQL
    {
        #region SELECT
        public const string SELECT_BASICA = "SELECT {0} FROM {1}";
        public const string SELECT_ALL_BASICA = "SELECT * FROM {0}";
        #endregion
    }
}
