﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace KRibbon.Model.SQL
{
    public partial class ScriptsSQL
    {
        #region VIEWS
        //public const string VIEWS... = "VIEWS...";
        #endregion
    }
}
