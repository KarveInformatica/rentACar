﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using static KRibbon.Utility.VariablesGlobales;

namespace KRibbon.Utility
{
    public class TablaAuxiliares
    {        
        public string propertiesresources { get; set; }
        public string nombretabladb { get; set; }
    }
}
