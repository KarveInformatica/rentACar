﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using KRibbon.Model;
namespace KRibbon.ViewModel
{

    class BanksViewModel: ViewModelBase
    {
        private ObservableCollection<KRibbon.Model.Banco> auxBanksList = new ObservableCollection<KRibbon.Model.Banco>();
        public BanksViewModel()
        {
            auxBanksList  = new ObservableCollection<KRibbon.Model.Banco>();
        }

     
    }
}
